
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Webmax\\VelmaClient\\CommandPacket"],["c","Webmax\\VelmaClient\\Exception\\BadPacketDefinitionException"],["c","Webmax\\VelmaClient\\Exception\\VelmaException"],["c","Webmax\\VelmaClient\\Model\\Contact"],["c","Webmax\\VelmaClient\\Model\\VelmaResponse"],["c","Webmax\\VelmaClient\\VelmaClient"]];
