
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Webmax\\VelmaClient\\VelmaClient"]];
